package com.example.caiye.lab9.model;

/**
 * Created by caiye on 2017/12/23.
 */

public class Repos {
    private String name;
    private String description;
    private String language;

    public String getName() { return name; }
    public String getDescription(){ return description; }
    public String getLanguage() { return language; }
}
