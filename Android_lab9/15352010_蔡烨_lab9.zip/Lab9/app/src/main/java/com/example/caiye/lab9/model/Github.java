package com.example.caiye.lab9.model;

/**
 * Created by caiye on 2017/12/23.
 */

public class Github {
    private String login;
    private String blog;
    private int id;

    public String getLogin(){ return login; }
    public String getBlog() { return blog; }
    public int getId() { return id; }
}
